$.import('com.sap','system');
$.import('com.sap','io');

// get method type
var method = $.request.getMethod();
method = method.toUpperCase();

// retrieve the id as parameter if exist 
var id = $.request.getParameter('id');
var count = $.request.getParameter('count');

// switch based on method type
if ((method === 'POST')) {
	// create
	createDaily_report_test();
} else if ((method === 'GET')) {
	// read
	if (id) {
    	readDaily_report_testEntity(id);
    } else if (count != null) {
    	countDaily_report_test();
    } else {
    	readDaily_report_testList();
    }
} else if ((method === 'PUT')) {
	// update
	updateDaily_report_test(id);
} else if ((method === 'DELETE')) {
	// delete
	deleteDaily_report_test(id);
} else {
	makeError(javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST, 1, "Invalid HTTP Method");
}

// flush and close the response
$.response.getWriter().flush();
$.response.getWriter().close();

// print error
function makeError(httpCode, errCode, errMessage) {
    var body = {'err': {'code': errCode, 'message': errMessage}};
    $.response.setStatus(httpCode);
    $.response.setHeader("Content-Type", "application/json");
    $.response.getWriter().print(JSON.stringify(body));
}

// create entity by parsing JSON object from request body
function createDaily_report_test() {
    delete_DailyReportTest_Table();
    
    var input = $.com.sap.io.read($.request.getReader());
    var message = JSON.parse(input);
    var connection = $.datasource.getConnection();
    try {
        var sql = "INSERT INTO DAILY_REPORT_TEST (";
        sql += "ID"
        sql += ",";
        sql += "DATE"
        sql += ",";
        sql += "COST_CENTER"
        sql += ",";
        sql += "CPU_COUNT"
        sql += ",";
        sql += "MEM_SIZE"
        sql += ",";
        sql += "DISK_SIZE"
        sql += ") VALUES ("; 
        sql += "?"
        sql += ",";
        sql += "?"
        sql += ",";
        sql += "?"
        sql += ",";
        sql += "?"
        sql += ",";
        sql += "?"
        sql += ",";
        sql += "?"
        sql += ")";

        var statement = connection.prepareStatement(sql);
        var i = 0;
        var id = $.db.getNext('DAILY_REPORT_TEST_ID');
        statement.setInt(++i, id);
        statement.setString(++i, message.date);
        statement.setString(++i, message.cost_center);
        statement.setString(++i, message.cpu_count);
        statement.setString(++i, message.mem_size);
        statement.setString(++i, message.disk_size);
        statement.executeUpdate();
        $.response.getWriter().println(id);
    } finally {
        connection.close();
    }
}

// read single entity by id and print as JSON object to response
function readDaily_report_testEntity(id) {
	var connection = $.datasource.getConnection();
    try {
    	var result;
        var sql = "SELECT * FROM DAILY_REPORT_TEST WHERE ID = ?";
        var statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        var resultSet = statement.executeQuery();
        var value;
        while (resultSet.next()) {
        	result = createEntity(resultSet);
        }
        var text = JSON.stringify(result, null, 2);
        $.response.getWriter().println(text);
    } finally {
        connection.close();
    }
}

// read all entities and print them as JSON array to response
function readDaily_report_testList() {
	var connection = $.datasource.getConnection();
    try {
    	var result = {};
        result.data = [];
        var sql = "SELECT * FROM DAILY_REPORT_TEST";
        var statement = connection.prepareStatement(sql);
        var resultSet = statement.executeQuery();
        var value;
        while (resultSet.next()) {
        	result.data.push(createEntity(resultSet));
        }
        var text = JSON.stringify(result, null, 2);
        $.response.getWriter().println(text);
    } finally {
        connection.close();
    }
}

//create entity as JSON object from ResultSet current Row
function createEntity(resultSet, data) {
	var result = {};
    var value;
    value = resultSet.getInt("ID");
    result["id"] = value;
    value = resultSet.getString("DATE");
    result["date"] = value;
    value = resultSet.getString("COST_CENTER");
    result["cost_center"] = value;
    value = resultSet.getString("CPU_COUNT");
    result["cpu_count"] = value;
    value = resultSet.getString("MEM_SIZE");
    result["mem_size"] = value;
    value = resultSet.getString("DISK_SIZE");
    result["disk_size"] = value;
    return result;
}

// update entity by id
function updateDaily_report_test(id) {
	var input = $.com.sap.io.read($.request.getReader());
    var message = JSON.parse(input);
    var connection = $.datasource.getConnection();
    try {
        var sql = "UPDATE DAILY_REPORT_TEST SET ";
        sql += "DATE = ?"
        sql += ",";
        sql += "COST_CENTER = ?"
        sql += ",";
        sql += "CPU_COUNT = ?"
        sql += ",";
        sql += "MEM_SIZE = ?"
        sql += ",";
        sql += "DISK_SIZE = ?"
        sql += " WHERE ID = ?";
        var statement = connection.prepareStatement(sql);
        var i = 0;
        statement.setString(++i, message.date);
        statement.setString(++i, message.cost_center);
        statement.setString(++i, message.cpu_count);
        statement.setString(++i, message.mem_size);
        statement.setString(++i, message.disk_size);
        statement.setInt(++i, id);
        statement.executeUpdate();
        $.response.getWriter().println(id);
    } finally {
        connection.close();
    }
}

// delete entity
function deleteDaily_report_test(id) {
	var connection = $.datasource.getConnection();
    try {
    	var sql = "DELETE FROM DAILY_REPORT_TEST WHERE ID = ?";
        var statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        var resultSet = statement.executeUpdate();
        $.response.getWriter().println(id);
    } finally {
        connection.close();
    }
}

function countDaily_report_test() {
	var count;
	var connection = $.datasource.getConnection();
	try {
	    var statement = connection.createStatement();
	    var rs = statement.executeQuery('SELECT COUNT(*) FROM DAILY_REPORT_TEST');
	    while (rs.next()) {
	        count = rs.getInt(1);
	    }
	} finally {
	    connection.close();
	}
	$.response.getWriter().println(count);
}

//custom fuction
function delete_DailyReportTest_Table() {
    var connection = $.datasource.getConnection();
    try {
    	var sql = "DELETE FROM DAILY_REPORT_TEST";
        var statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        //statement.setString(1, id);
        //var resultSet = statement.executeUpdate();
        //$.response.getWriter().println(id);
    } finally {
        connection.close();
    }
}