var system = require('com/sap/system');
var io = require('com/sap/io');

// get method type
var method = request.getMethod();
method = method.toUpperCase();

//get primary keys (one primary key is supported!)
var idParameter = getPrimaryKey();

// retrieve the id as parameter if exist 
var id = request.getParameter('userid');
var count = request.getParameter('count');

if(!hasConflictingParameters()){
    // switch based on method type
    if ((method === 'POST')) {
        // create
        createTest();
    } else if ((method === 'GET')) {
        // read
        if (id) {
            readTestEntity(id);
        } else if (count !== null) {
            countTest();
        } else {
            readTestList();
        }
    } else if ((method === 'PUT')) {
        // update
        updateTest();    
        
    } else if ((method === 'DELETE')) {
        // delete
        if(isInputParameterValid(idParameter)){
            deleteTest(id);
        }
        
    } else {
        makeError(javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST, 1, "Invalid HTTP Method");
    }    
}



// flush and close the response
response.getWriter().flush();
response.getWriter().close();

function hasConflictingParameters(){
	var idParameter = getPrimaryKey();
    var id = request.getParameter(idParameter);
    var count = request.getParameter('count');
    if(id !== null && count !== null){
        makeError(javax.servlet.http.HttpServletResponse.SC_EXPECTATION_FAILED, 1, "Precondition failed: conflicting parameters - id, count");
        return true;
    }
    return false;
}

function isInputParameterValid(paramName){
    var param = request.getParameter(paramName);
    if(param === null || param === undefined){
        makeError(javax.servlet.http.HttpServletResponse.SC_PRECONDITION_FAILED, 1, "Expected parameter is missing: " + paramName);
        return false;
    }
    return true;
}

// print error
function makeError(httpCode, errCode, errMessage) {
    var body = {'err': {'code': errCode, 'message': errMessage}};
    response.setStatus(httpCode);
    response.setHeader("Content-Type", "application/json");
    response.getWriter().print(JSON.stringify(body));
}

// create entity by parsing JSON object from request body
function createTest() {
    var input = io.read(request.getReader());
    var message = JSON.parse(input);
    var connection = datasource.getConnection();
    try {
        var sql = "INSERT INTO TEST (";
        sql += "ID";
        sql += ",";
        sql += "NAME";
        sql += ",";
        sql += "DESCRIPTION";
        sql += ") VALUES ("; 
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ",";
        sql += "?";
        sql += ")";

        var statement = connection.prepareStatement(sql);
        var i = 0;
        var id = db.getNext('TEST_ID');
        statement.setInt(++i, id);
        statement.setString(++i, message.name);
        statement.setString(++i, message.description);
        statement.executeUpdate();
        response.getWriter().println(id);
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
}

// read single entity by id and print as JSON object to response
function readTestEntity(id) {
    var connection = datasource.getConnection();
    try {
        var result = "";
        var sql = "SELECT * FROM TEST WHERE "+pkToSQL();
        var statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        
        var resultSet = statement.executeQuery();
        var value;
        while (resultSet.next()) {
            result = createEntity(resultSet);
        }
        if(result.length === 0){
            makeError(javax.servlet.http.HttpServletResponse.SC_NOT_FOUND, 1, "Record with id: " + id + " does not exist.");
        }
        var text = JSON.stringify(result, null, 2);
        response.getWriter().println(text);
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
}

// read all entities and print them as JSON array to response
function readTestList() {
    var connection = datasource.getConnection();
    try {
        var result = {};
        result.data = [];
        var sql = "SELECT * FROM TEST";
        var statement = connection.prepareStatement(sql);
        var resultSet = statement.executeQuery();
        var value;
        while (resultSet.next()) {
            result.data.push(createEntity(resultSet));
        }
        var text = JSON.stringify(result, null, 2);
        response.getWriter().println(text);
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
}

//create entity as JSON object from ResultSet current Row
function createEntity(resultSet, data) {
    var result = {};
    var value;
    value = resultSet.getInt("ID");
    result.id = value;
    value = resultSet.getString("NAME");
    result.name = value;
    value = resultSet.getString("DESCRIPTION");
    result.description = value;
    return result;
}

// update entity by id
function updateTest() {
    var input = io.read(request.getReader());
    var message = JSON.parse(input);
    var connection = datasource.getConnection();
    try {
        var sql = "UPDATE TEST SET ";
        sql += "NAME = ?";
        sql += ",";
        sql += "DESCRIPTION = ?";
        sql += " WHERE ID = ?";
        var statement = connection.prepareStatement(sql);
        var i = 0;
        statement.setString(++i, message.name);
        statement.setString(++i, message.description);
        var id = "";
        id = message.id;
        statement.setInt(++i, id);
        statement.executeUpdate();
        response.getWriter().println(id);
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
}

// delete entity
function deleteTest(id) {
    var connection = datasource.getConnection();
    try {
        var sql = "DELETE FROM TEST WHERE "+pkToSQL();
        var statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        var resultSet = statement.executeUpdate();
        response.getWriter().println(id);
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
}

function countTest() {
    var count = 0;
    var connection = datasource.getConnection();
    try {
        var statement = connection.createStatement();
        var rs = statement.executeQuery('SELECT COUNT(*) FROM TEST');
        while (rs.next()) {
            count = rs.getInt(1);
        }
    } catch(e){
        response.getWriter().println(e.message);
    } finally {
        connection.close();
    }
    response.getWriter().println(count);
}

function getPrimaryKeys(){
    var result = [];
    var i = 0;
    result[i++] = 'ID';
    if(result == 0){
        throw new Exception("There is no primary key");
    }else if(result.length > 1){
    	 throw new Exception("More than one Primary Key is not supported.");
    }
    return result;
}

function getPrimaryKey(){
	var idParameter = getPrimaryKeys()[0].toLowerCase();
}
function pkToSQL(){
    var pks = getPrimaryKeys();
    return pks[0] + " = ?";
}